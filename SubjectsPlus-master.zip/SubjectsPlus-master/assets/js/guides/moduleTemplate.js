/**
* Something something.
* 
* 
*  
**/
/*jslint browser: true*/
/*global $, jQuery, alert*/

/*
 
 
 function thing() {
 
 	var myThing = {
 	
 	settings : {
 	},
 	strings : {
 	},
 	bindUiActions : function() {
 	},
 	init : function() {
 	}
 };
 
 	return myThing;
 }

*/


