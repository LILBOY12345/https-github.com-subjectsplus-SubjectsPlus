//Spanish translation of all output to user for the subsplus_cat_link plugin

CKEDITOR.lang['es']['subsplus_cat_link.Label'] = 'Vinculo al Catalogo de Grabacion';
CKEDITOR.lang['es']['subsplus_cat_link.Title'] = 'Vinculo al Cat&agravelogo de Grabaci&ograven';

CKEDITOR.lang['es']['subsplus_cat_link.Tab1Label'] = 'Vinculo a Encabezamientos de Materia';
CKEDITOR.lang['es']['subsplus_cat_link.Tab1Prefix'] = 'Texto Para el Prefijo (opcional)';
CKEDITOR.lang['es']['subsplus_cat_link.Tab1Subject'] = 'LC Encabezamiento de Materia';
CKEDITOR.lang['es']['subsplus_cat_link.Tab1HtmlStrong'] = 'Ejemplo';
CKEDITOR.lang['es']['subsplus_cat_link.Tab1Html'] = '(los textos que no estas enlazado son de el texto para el prefijo opcional):';
CKEDITOR.lang['es']['subsplus_cat_link.Tab1Button'] = 'Agregar un Vinculo';
CKEDITOR.lang['es']['subsplus_cat_link.Tab1ValidateAlert'] = 'Encabezamientos de Materia no pueden estar blanco!';

CKEDITOR.lang['es']['subsplus_cat_link.Tab2Label'] = 'Vinculo a Los Resultados de B&ugravesqueda';
CKEDITOR.lang['es']['subsplus_cat_link.Tab2Keywords'] = 'Palabras Clave';
CKEDITOR.lang['es']['subsplus_cat_link.Tab2EG'] = 'carros r&agravepidos';
CKEDITOR.lang['es']['subsplus_cat_link.Tab2Button'] = 'Agregar un Vinculo';
CKEDITOR.lang['es']['subsplus_cat_link.Tab2ValidateAlert'] = 'Caracter&igravestica de Palabras Clave no puede estar blanco!';

CKEDITOR.lang['es']['subsplus_cat_link.Tab3Label'] = 'Vinculo para n&ugravemero de clasificaci&ograven';
CKEDITOR.lang['es']['subsplus_cat_link.Tab3CallNum'] = 'N&ugravemero de Clasificaci&ograven (E.g., DVD 3001)';
CKEDITOR.lang['es']['subsplus_cat_link.Tab3Text'] = 'T&igravetulo o Vinculo de Texto';
CKEDITOR.lang['es']['subsplus_cat_link.Tab3Button'] = 'Agregar un Vinculo';
CKEDITOR.lang['es']['subsplus_cat_link.Tab2ValidateCallLabel'] = 'N&ugravemero de Clasificaci&ograven y T&igravetulo no pueden estar blanco!';
CKEDITOR.lang['es']['subsplus_cat_link.Tab2ValidateCall'] = 'N&ugravemero de Clasificaci&ograven no puede estar blanco!';
CKEDITOR.lang['es']['subsplus_cat_link.Tab2ValidateLabel'] = 'El T&igravetulo no puede estar blanco!';