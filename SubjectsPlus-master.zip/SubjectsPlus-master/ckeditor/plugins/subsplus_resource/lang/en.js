//English translation of all output to userfor the subsplus_resource plugin

CKEDITOR.lang['en']['subsplus_resource.Label'] = 'Insert Resource Token';
CKEDITOR.lang['en']['subsplus_resource.title'] = 'Insert Resource Token';

CKEDITOR.lang['en']['subsplus_resource.InstructionsStrong1'] = 'Search';
CKEDITOR.lang['en']['subsplus_resource.Instructions1'] = 'for a resource saved in SubjectsPlus';
CKEDITOR.lang['en']['subsplus_resource.InstructionsStrong2'] = 'Tick';
CKEDITOR.lang['en']['subsplus_resource.Instructions2'] = 'the button next to the desired resource and click OK (bottom)';
CKEDITOR.lang['en']['subsplus_resource.Button'] = 'Search';
CKEDITOR.lang['en']['subsplus_resource.IconsCheckbox'] = 'Include icons?'
CKEDITOR.lang['en']['subsplus_resource.DescCheckbox'] = 'Include description?'
CKEDITOR.lang['en']['subsplus_resource.NoteCheckbox'] = 'Include note?'
CKEDITOR.lang['en']['subsplus_resource.ValidateRadio'] = 'No Resource chosen!';